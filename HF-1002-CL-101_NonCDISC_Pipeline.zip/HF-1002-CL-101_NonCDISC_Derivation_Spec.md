# HF-1002-CL-101 — Non-CDISC Programming Pipeline & Derivation Spec

**FICTIONAL / SYNTHETIC — FOR DEMONSTRATION AND TRAINING ONLY.**

Demonstrates programming clinical trial tables **without a CDISC (SDTM/ADaM) layer** — straight from raw EDC extracts through home-grown analysis datasets to populated tables.

## Pipeline

```
raw_edc/*.csv  ──(01_build_analysis_datasets.py)──►  analysis_data/*.csv  ──(02_generate_tables.py)──►  tables_output/*.txt  +  HF-1002-CL-101_Populated_Tables.docx
   raw EDC (Rave-style, uncoded)        non-CDISC analysis datasets              populated TFL tables (SAS PROC REPORT look)
```

Run order (from this folder):

```
python 01_build_analysis_datasets.py     # raw EDC  -> analysis_data/
python 02_generate_tables.py             # analysis_data/ -> tables_output/ + Word doc
```

Requires Python with `pandas`, `numpy`, `python-docx`. Everything is computed from the synthetic data — no values are hard-coded.

## Why analysis datasets at all (non-CDISC ≠ no analysis data)

The raw EDC has no baseline, no change-from-baseline, no TEAE/DLT flags, no population flags. Those derivations must happen somewhere. We do them once, into our own (non-ADaM) analysis datasets, so every table program stays a thin summary step and shares one source of truth. This is the same work ADaM standardizes — minus the CDISC standard, metadata, and define.xml.

## Analysis datasets (`analysis_data/`)

### an_subject — one row per subject (18)
| Variable | Derivation |
|----------|-----------|
| COHORT, COHORTLBL, DOSE_VG | from `el` (eligibility/enrollment) |
| AGE, SEX, RACE | from `dm` |
| AGEGR1 | `<65` / `>=65` from AGE |
| BL_LVEF, BL_NYHA | screening values from `el` |
| TRTSDT, EXVOL_ML | infusion date/volume from `ex` |
| SAFFL | "Y" if subject received any HF-1002 (has `ex` record) |
| FASFL | "Y" if `ex.EXADMIN_COMPLETE` = Y (complete planned infusion) |
| DLTFL | "Y" if reached/exceeded DLT window (Day 1–29) or had an in-window DLT |
| COMPLFL | "Y" if `ds.PRIMARY_OBS_COMPLETED` = Y |
| DTHFL | "Y" if `ds.DSDECOD` = DEATH |
| DSDECOD, DSREAS, DSDAT | disposition from `ds` |

### an_ae — one row per AE (57)
| Variable | Derivation |
|----------|-----------|
| AEDY | AE onset study day = AESTDT − TRTSDT + 1 |
| TEAEFL | "Y" if onset on/after infusion date |
| RELFL | "Y" if AEREL ∈ {possibly, probably, related} |
| SERFL | "Y" if AESER = Y |
| SEVGR, GE3FL | numeric CTCAE grade; GE3FL "Y" if grade ≥ 3 |
| DLTWINFL | "Y" if AEDY in 1–29 (DLT window) |
| DLTFL | "Y" if raw AEDLT = Y **and** within DLT window |
| FATALFL | "Y" if AEOUT = FATAL |

### an_lb — one row per lab result (2,131)
| Variable | Derivation |
|----------|-----------|
| AVAL | numeric `LBORRES` |
| ABLFL | "Y" for screening record |
| BASE | screening AVAL per subject × test |
| CHG | AVAL − BASE (post-baseline rows) |
| ANRIND | raw normal-range indicator (LOW/NORMAL/HIGH) |
| LBALERT | ">5xULN" / ">3xULN" for ALT or AST vs `LBORNRHI` (liver-alert / DLT support) |

### an_eff — one row per subject × parameter × visit (503)
Parameters: LVEF central (LVEFC) & local (LVEFL), pVO2, 6MWT, MLHFQ, KCCQ, NYHA.
| Variable | Derivation |
|----------|-----------|
| AVAL | value from the relevant efficacy form (`ec`, `cpet`, `walk6`, `mlhfq`, `kccq`, `nyha`) |
| ABLFL | "Y" for screening |
| BASE | screening AVAL per subject × parameter |
| CHG | AVAL − BASE (post-baseline rows) |
| FASFL | carried from an_subject |

## Tables produced (`tables_output/` + Word doc)

| Table | Title | Source dataset | Population |
|-------|-------|----------------|-----------|
| 14.1.1 | Demographics & Baseline Characteristics | an_subject | Safety Set |
| 14.1.2 | Participant Disposition | an_subject | Safety Set |
| 14.1.3 | Extent of Exposure | an_subject | Safety Set |
| 14.3.1.1 | Overall Summary of TEAEs | an_ae, an_subject | Safety Set |
| 14.3.1.2 | TEAEs by Verbatim Term (uncoded) | an_ae | Safety Set |
| 14.3.3.1 | Dose-Limiting Toxicities by Cohort | an_ae | DLT-Evaluable |
| 14.2.1.1 | Change from Baseline in LVEF (Central Reader) | an_eff | FAS |
| 14.2.4.2 | Change from Baseline in KCCQ | an_eff | FAS |

Columns: Cohort 1 (Low) / 2 (Mid) / 3 (High) / Total. Continuous = Mean (SD), Median, Min–Max; categorical = n (%); change endpoints carry a descriptive t-based 95% CI. Observed cases only (n shown per visit), so the death (2005), withdrawal (3006), and missed M6 (1005) flow through as reduced denominators.

## Caveats (state these when showing the demo)

- **AEs are uncoded.** Table 14.3.1.2 groups by investigator verbatim term; a true by-SOC/PT table needs MedDRA coding (the one deliberately stubbed step).
- **Non-submission path.** Direct-from-EDC programming suits operational/DSMB/interim reads. FDA submissions generally still expect CDISC SDTM/ADaM; treat this as the rapid path or the derivation logic that precedes CDISC.
- **Derivations live in code.** Without ADaM/define.xml, traceability rests on this spec + the commented programs — which is exactly what they provide.
